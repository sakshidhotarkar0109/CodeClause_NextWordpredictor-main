# CodeClause_NextWordpredictor
Next Word Predictor using Java language.

Predicts next word you are trying to type in a search bar
